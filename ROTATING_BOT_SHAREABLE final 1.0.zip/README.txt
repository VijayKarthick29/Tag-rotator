========================================================================
             UNIVERSAL DISCORD SERVER CLAN BADGE ROTATOR
========================================================================

FEATURES:
- Rotates server clan tag badge & colors automatically for ALL members!
- Cycles through all 14 official Discord color presets for each badge.
- Changes color every 1 minute (interval_seconds: 60).
- Excludes Mushroom (#3), Trophy/Cup (#28), Pot/Money Bag (#29), and Dollar Sign (#30).
- Automatic smart retry on Discord rate-limit locks (never skips colors).
- Works with any server where your account has "Manage Server" or "Administrator".

HOW TO USE:
1. Double-click "start_guild_rotator.bat".
2. On first launch, it will ask for:
   - Your Discord User/Admin Token (it verifies and saves it to config.json).
   - Your Server ID (or choose from the list of servers found).
3. The bot will automatically begin rotating all 14 colors every 1 minute!

TO RUN 24/7 IN THE BACKGROUND:
- Double-click "install_24_7_startup.bat" to start automatically whenever Windows boots up.
